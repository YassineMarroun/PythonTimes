from setuptools import setup

setup(

    name="CalculationPackage",
    version="1.0",
    description="Rounding and Potency Package",
    author="Yassine",
    author_email="el.yasin@hotmail.com",
    url="https://github.com/YassineMarroun",
    packages=["Calculations", "Calculations.RoundingPotency"]
)

def potency(base, exponent):
    print("The result of the potency is: ", base ** exponent)


def round_out(number):
    print("The result of the round out is: ", round(number))

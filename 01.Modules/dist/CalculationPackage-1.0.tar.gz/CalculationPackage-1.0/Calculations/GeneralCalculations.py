def addition(op1, op2):
    print("The result of the addition is: ", op1 + op2)


def subtraction(op1, op2):
    print("The result of the subtraction is: ", op1 - op2)


def multiplication(op1, op2):
    print("The result of the multiplication is: ", op1 * op2)


def division(dividend, divider):
    print("The result of the division is: ", dividend / divider)


def potency(base, exponent):
    print("The result of the potency is: ", base ** exponent)


def round_out(number):
    print("The result of the round out is: ", round(number))
